<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AuthController extends Controller
{
    public function showLoginForm()
    {
        return view('auth.login');
    }

    public function login(Request $request)
    {
        $credentials = $request->only('name', 'password');

        if (Auth::attempt($credentials)) {
            return redirect('post/list');
        }

        return redirect()->route('login')->withErrors(['message' => 'Invalid credentials']);
    }


    public function showRegistrationForm()
    {
        return view('auth.register');
    }

    public function register(Request $request)
    {
        $request->validate([
            'name' => 'required|unique:users',
            'password' => 'required|min:6',
        ]);

        // dd($request->all());

        User::create([
            'name' => $request->input('name'),
            'password' => bcrypt($request->input('password')),
        ]);

        return redirect()->route('login')->with('message', 'Registrasi berhasil!');
    }

    public function logout()
    {
        Auth::logout();
        return redirect()->route('login')->with('message', 'Anda berhasil log out.');
    }
}
