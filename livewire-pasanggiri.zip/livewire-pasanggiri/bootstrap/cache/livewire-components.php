<?php return array (
  'post.absensi' => 'App\\Http\\Livewire\\Post\\Absensi',
  'post.add' => 'App\\Http\\Livewire\\Post\\Add',
  'post.edit' => 'App\\Http\\Livewire\\Post\\Edit',
  'post.perolehan-list' => 'App\\Http\\Livewire\\Post\\PerolehanList',
  'post.peserta-list' => 'App\\Http\\Livewire\\Post\\PesertaList',
  'post.post-list' => 'App\\Http\\Livewire\\Post\\PostList',
);